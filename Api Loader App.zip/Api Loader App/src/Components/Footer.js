import React from 'react'

function Footer() {
    return (
        <div className='mainfooter'>
            <h3 className='fheader'>This is @Copyright Codecraftiness 2023 </h3>
            <div className='social'>
                <span className='one'><i class="fa-brands fa-instagram fa-2xl"></i></span>
                <span className='two'><i class="fa-brands fa-linkedin fa-2xl"></i></span>
                <span className='three'><i class="fa-brands fa-github fa-2xl"></i></span>
                <span className='four'><i class="fa-brands fa-youtube fa-2xl"></i></span></div>
        </div>
    )
}

export default Footer