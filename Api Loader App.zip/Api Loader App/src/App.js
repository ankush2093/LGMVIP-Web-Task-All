import './App.css';
import Footer from './Components/Footer';
import GetUsers from './Components/GetUsers';
import React from 'react';

function App() {
  return (
    <div className='maincard'>
        <GetUsers/> 
        <Footer/>
    </div>
  );
}

export default App;
