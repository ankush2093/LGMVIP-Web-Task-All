# API call with Loader
### Task2 - You have to display some users data by making API Call using React. 
P.S. Show a loader while the API fetches the data.

![image](https://user-images.githubusercontent.com/71166016/178049477-edd2cf70-83b2-4c27-aed2-e7caf234e26e.png)
![image](https://user-images.githubusercontent.com/71166016/178049884-43ee02f3-f44f-4b5c-88b0-ece9be2cde5e.png)
![image](https://user-images.githubusercontent.com/71166016/178049282-06c2eca9-f3ce-46ba-8ff0-c6db5a27bc36.png)

